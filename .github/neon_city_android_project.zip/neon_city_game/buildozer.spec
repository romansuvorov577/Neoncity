[app]
title = Neon City
package.name = neoncity
package.domain = org.openai
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 1.0
requirements = python3,kivy
orientation = landscape
fullscreen = 1
android.permissions =
# android.api is selected by the installed Buildozer/python-for-android version
android.minapi = 23
android.archs = arm64-v8a
android.allow_backup = False

[buildozer]
log_level = 2
warn_on_root = 1